"""
Services Package

Contains business logic services for the STR Compliance Toolkit:
- SearchService: Advanced search, suggestions, saved searches
- RegulationService: Regulation CRUD and filtering
- UpdateService: Update management and interactions
- UserInteractionService: Bookmarks, reminders, user sessions
- NotificationService: Alerts, preferences, digest generation
"""

from .search_service import SearchService
from .regulation_service import RegulationService
from .update_service import UpdateService
from .user_interaction_service import UserInteractionService
from .notification_service import NotificationService

__all__ = [
    'SearchService',
    'RegulationService', 
    'UpdateService',
    'UserInteractionService',
    'NotificationService'
] 